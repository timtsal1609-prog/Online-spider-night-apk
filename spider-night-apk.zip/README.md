# Сборка APK через GitHub

1. На github.com создай репозиторий (New repository, Public или Private).
2. Add file → Upload files: загрузи `index.html` и `multiplayer.js`, нажми Commit.
3. Add file → Create new file. В поле имени введи ровно: .github/workflows/build-apk.yml
   Вставь туда весь текст из файла build-apk.yml из архива, нажми Commit.
4. Вкладка Actions → Build APK → Run workflow (или она запустится сама после коммита). Сборка ~5-8 минут.
5. Открой завершённый запуск → внизу Artifacts → spider-night-apk. Скачается zip, внутри app-debug.apk.
6. Распакуй, установи APK (разреши установку из неизвестных источников).

Игре нужен интернет: three.js и онлайн подгружаются из сети.
