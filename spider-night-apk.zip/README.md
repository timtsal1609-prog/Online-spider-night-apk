# Сборка APK через GitHub

1. На github.com создай репозиторий (New repository).
2. Add file → Upload files: загрузи `index.html` и `multiplayer.js`, нажми Commit.
3. Add file → Create new file. В поле имени введи ровно: .github/workflows/build-apk.yml
   Вставь туда весь текст из файла build-apk.yml, нажми Commit.
4. Вкладка Actions → Build APK → Run workflow. Сборка ~5-8 минут.
5. Завершённый запуск → внизу Artifacts → spider-night-apk → внутри app-debug.apk.

Если репозиторий уже есть: замени в нём файл multiplayer.js новым (Upload files с тем же именем перезапишет).
Игре нужен интернет: three.js и онлайн подгружаются из сети.
