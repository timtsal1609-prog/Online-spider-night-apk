// Spider Night — клиентская часть мультиплеера.
// Подключается после основного скрипта игры (использует его глобальные переменные)
// и вызывается из игрового цикла через MP.frame(dt).
(function () {
  'use strict';

  const LSK = 'spider_night_mp_v1';
  const EMO = ['👋', '😂', '👍', '🔥', '🕸️'];
  const q = id => document.getElementById(id);

  /* ---------- настройки ---------- */
  const S = Object.assign(
    { name: 'Паук' + (10 + Math.floor(Math.random() * 90)), code: '' },
    (() => { try { return JSON.parse(localStorage.getItem(LSK)) || {}; } catch (e) { return {}; } })()
  );
  const saveS = () => { try { localStorage.setItem(LSK, JSON.stringify({ name: S.name, code: S.code })); } catch (e) {} };

  /* ---------- интерфейс ---------- */
  const css = document.createElement('style');
  css.textContent = `
#mpPanel{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(13,11,26,.9);z-index:14;touch-action:pan-y}
#mpBox{width:min(92vw,460px);max-height:90vh;overflow:auto;background:rgba(13,11,26,.96);border:1px solid var(--amber);border-radius:14px;padding:16px;display:flex;flex-direction:column;gap:10px;color:var(--ink)}
#mpBox h2{font-family:Unbounded,Impact,sans-serif;margin:0;font-size:22px}
#mpBox label{display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:15px}
#mpBox input{flex:1;min-width:0;max-width:62%;background:#1a1730;color:var(--ink);border:1px solid var(--amber);border-radius:6px;padding:8px;font-size:15px;-webkit-user-select:text;user-select:text}
#mpSt{margin:0;font-size:14px;opacity:.9;line-height:1.4}
#mpSt.err{color:#ff7a7a;opacity:1}
#mpList{font-size:14px;display:flex;flex-direction:column;gap:4px}
#mpList i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px;border:1px solid #fff}
#mpIdle,#mpLive{display:flex;flex-direction:column;gap:10px}
.mpRow{display:flex;gap:8px}
.mpRow input{text-transform:uppercase;letter-spacing:.12em;text-align:center}
#mpCreate,#mpJoin,#mpShare{background:var(--amber);color:#1a1020;border:0;border-radius:999px;padding:10px 16px;font-size:16px;font-weight:700}
#mpLeave{background:transparent;color:var(--ink);border:1px solid #ff7a7a;border-radius:999px;padding:8px;font-size:15px}
#mpCodeBox{text-align:center;font-size:14px;opacity:.9}
#mpCode{display:block;font-family:Unbounded,Impact,sans-serif;font-size:34px;letter-spacing:.14em;color:var(--amber);margin-top:4px;-webkit-user-select:text;user-select:text}
#mpClose{background:transparent;color:var(--ink);border:1px solid var(--ink);border-radius:999px;padding:8px;font-size:15px}
#mpHint{font-size:12px;opacity:.6;margin:0;line-height:1.4}
#mpOpen{background:transparent;color:var(--ink);border:2px solid var(--ink);border-radius:999px;padding:10px 26px;font-size:16px;margin-top:10px}
#mpChatBtn,#mpEmoBtn{display:none;top:calc(12px + env(safe-area-inset-top,0px));width:44px;height:44px;font-size:20px}
#mpChatBtn{right:calc(176px + env(safe-area-inset-right,0px))}
#mpEmoBtn{right:calc(228px + env(safe-area-inset-right,0px))}
#mpEmoRow{position:fixed;top:calc(64px + env(safe-area-inset-top,0px));right:calc(176px + env(safe-area-inset-right,0px));display:none;gap:6px;z-index:11;background:var(--panel);padding:6px;border-radius:12px}
#mpEmoRow button{background:transparent;border:0;font-size:24px;padding:4px 6px}
#mpChatBar{position:fixed;top:calc(12px + env(safe-area-inset-top,0px));left:50%;transform:translateX(-50%);width:min(70vw,440px);display:none;gap:6px;z-index:11}
#mpChatBar input{flex:1;min-width:0;background:rgba(13,11,26,.92);color:var(--ink);border:1px solid var(--amber);border-radius:999px;padding:8px 14px;font-size:15px;-webkit-user-select:text;user-select:text}
#mpChatBar button{background:var(--amber);color:#1a1020;border:0;border-radius:999px;padding:8px 14px;font-size:15px;font-weight:700}
#mpLog{position:fixed;left:calc(14px + env(safe-area-inset-left,0px));top:calc(112px + env(safe-area-inset-top,0px));width:min(46vw,340px);display:flex;flex-direction:column;gap:3px;pointer-events:none;z-index:4}
#mpLog div{background:var(--panel);padding:4px 9px;border-radius:8px;font-size:13px;line-height:1.35;word-break:break-word}
#mpLog b{color:var(--amber)}
.cut #mpLog,.cut #mpChatBar,.cut #mpEmoRow{display:none!important}
`;
  document.head.appendChild(css);

  const ui = document.createElement('div');
  ui.innerHTML = `
<div id="mpPanel"><div id="mpBox">
  <h2>Онлайн</h2>
  <div id="mpIdle">
    <label>Имя <input id="mpName" maxlength="16" autocomplete="off"></label>
    <button id="mpCreate">Создать комнату</button>
    <div class="mpRow"><input id="mpCodeIn" maxlength="8" placeholder="Код комнаты" autocomplete="off" autocapitalize="characters" spellcheck="false"><button id="mpJoin">Войти</button></div>
  </div>
  <div id="mpLive" style="display:none">
    <div id="mpCodeBox">Код комнаты<b id="mpCode"></b></div>
    <button id="mpShare">Поделиться кодом</button>
    <button id="mpLeave">Выйти из комнаты</button>
  </div>
  <p id="mpSt"></p>
  <div id="mpList"></div>
  <button id="mpClose">Закрыть</button>
  <p id="mpHint">Нажми «Создать комнату» и отправь друзьям код. Друзья нажимают «Войти» и вводят его. Работает из любых стран. Комната живёт, пока в ней есть игроки.</p>
</div></div>
<div class="btn" id="mpEmoBtn">😀</div>
<div class="btn" id="mpChatBtn">💬</div>
<div id="mpEmoRow">${EMO.map((e, i) => `<button data-e="${i}">${e}</button>`).join('')}</div>
<div id="mpChatBar"><input id="mpMsg" maxlength="120" placeholder="Сообщение…" autocomplete="off"><button id="mpSend">➤</button></div>
<div id="mpLog"></div>`;
  document.body.appendChild(ui);

  // Кнопка «Онлайн» в главном меню (рядом с «Настройки») и в паузе
  const mpOpen = document.createElement('button');
  mpOpen.id = 'mpOpen';
  mpOpen.textContent = 'Онлайн';
  const setBtn = q('setBtn');
  if (setBtn && setBtn.parentNode) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:10px;align-items:center;align-self:flex-start;flex-wrap:wrap';
    setBtn.parentNode.insertBefore(row, setBtn);
    row.appendChild(setBtn);
    row.appendChild(mpOpen);
  }
  const mpOpen2 = document.createElement('button');
  mpOpen2.id = 'mpOpen2';
  mpOpen2.textContent = 'Онлайн';
  if (q('pm')) q('pm').appendChild(mpOpen2);

  const stopKeys = el => ['keydown', 'keyup', 'keypress'].forEach(t => el.addEventListener(t, e => e.stopPropagation()));
  ['mpName', 'mpCodeIn', 'mpMsg'].forEach(id => stopKeys(q(id)));

  /* ---------- сеть: комнаты через публичные MQTT-брокеры (WebSocket) ---------- */
  // Все игроки комнаты подписываются на одну тему и обмениваются сообщениями через брокер.
  // Своего сервера не нужно. Сообщения шлются сразу через два брокера (если один недоступен, работает другой),
  // дубликаты отсекаются по номеру сообщения.
  const BROKERS = ['wss://broker.hivemq.com:8884/mqtt', 'wss://broker.emqx.io:8084/mqtt'];
  const FALLBACK = 'wss://test.mosquitto.org:8081/mqtt';
  const MAXP = 8, ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let joined = false, myId = null, role = null, roomCode = '', busy = false;
  let sendT = 0, cosT = 0, lastCosKey = '', statusText = '';
  const remotes = new Map();

  function status(t, err) {
    statusText = t;
    const el = q('mpSt');
    el.textContent = t;
    el.className = err ? 'err' : '';
  }

  function refreshUi() {
    const on = joined;
    q('mpIdle').style.display = role ? 'none' : 'flex';
    q('mpLive').style.display = role ? 'flex' : 'none';
    q('mpCode').textContent = roomCode || '…';
    q('mpChatBtn').style.display = on ? 'flex' : 'none';
    q('mpEmoBtn').style.display = on ? 'flex' : 'none';
    if (!on) { q('mpEmoRow').style.display = 'none'; closeChat(); }
    const label = on ? 'Онлайн: ' + (remotes.size + 1) : 'Онлайн';
    mpOpen.textContent = label; mpOpen2.textContent = label;
    const list = q('mpList');
    list.innerHTML = '';
    if (on) {
      const add = (name, cos, me) => {
        const d = document.createElement('div');
        const dot = document.createElement('i');
        dot.style.background = cos ? cos.l : '#ffb347';
        d.appendChild(dot);
        d.appendChild(document.createTextNode(name + (me ? ' (ты)' : '')));
        list.appendChild(d);
      };
      add(S.name, myCos(), true);
      remotes.forEach(r => add(r.name, r.cos, false));
    }
  }

  function myCos() {
    try {
      const c = costumes[cfg[ck()] | 0] || costumes[0];
      return { b: c.b, l: c.l, a: c.a, e: c.e };
    } catch (e) { return { b: '#17122e', l: '#ffb347', a: 0xffb347, e: 0x553300 }; }
  }
  const cosKey = c => c.b + c.l + c.a + c.e;

  // проверка данных, пришедших от других игроков
  const num = (v, lo, hi, d) => { v = +v; return Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d; };
  const hexOk = v => typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v);
  const cleanName = n => String(n || '').replace(/[^\p{L}\p{N} _.\-]/gu, '').trim().slice(0, 16) || 'Паук';
  function cleanCos(c) {
    if (!c || typeof c !== 'object' || !hexOk(c.b) || !hexOk(c.l)) return null;
    return { b: c.b, l: c.l, a: num(c.a, 0, 0xffffff, 0xffb347) | 0, e: num(c.e, 0, 0xffffff, 0x553300) | 0 };
  }
  function cleanState(m) {
    const o = {
      x: num(m.x, -3000, 3000, 0), y: num(m.y, -100, 2000, 0), z: num(m.z, -3000, 3000, 0),
      ry: num(m.ry, -20, 20, 0), vx: num(m.vx, -150, 150, 0), vy: num(m.vy, -150, 150, 0), vz: num(m.vz, -150, 150, 0),
      g: m.g ? 1 : 0, cl: m.cl ? 1 : 0, sw: m.sw ? 1 : 0, pu: m.pu ? 1 : 0, civ: m.civ ? 1 : 0, dr: m.dr ? 1 : 0, hid: m.hid ? 1 : 0, w: null
    };
    if (Array.isArray(m.w) && m.w.length === 3) o.w = [num(m.w[0], -3000, 3000, 0), num(m.w[1], -100, 2000, 0), num(m.w[2], -3000, 3000, 0)];
    return o;
  }

  /* --- минимальный клиент MQTT 3.1.1 поверх WebSocket --- */
  const TE = new TextEncoder(), TD = new TextDecoder();
  const u8 = x => (x instanceof Uint8Array ? x : new Uint8Array(x));
  function remLen(n) { const a = []; do { let d = n % 128; n = Math.floor(n / 128); if (n > 0) d |= 128; a.push(d); } while (n > 0); return a; }
  function mqPacket(first, ...parts) {
    parts = parts.map(u8);
    const len = parts.reduce((t, x) => t + x.length, 0), h = remLen(len);
    const out = new Uint8Array(1 + h.length + len);
    out[0] = first; out.set(h, 1);
    let o = 1 + h.length;
    parts.forEach(x => { out.set(x, o); o += x.length; });
    return out;
  }
  function mqStr(str) { const b = TE.encode(str), o = new Uint8Array(2 + b.length); o[0] = b.length >> 8; o[1] = b.length & 255; o.set(b, 2); return o; }
  function mqPublish(L, topic, text) {
    const t = TE.encode(topic), pl = TE.encode(text);
    L.ws.send(mqPacket(0x30, [t.length >> 8, t.length & 255], t, pl));
  }

  let links = [], peers = new Map(), seq = 0, joinMode = false, topicBase = '', fallbackOn = false, lastOk = 0, lastHiReply = 0;
  let tHi = 0, tSweep = 0, tWatch = 0, tFail = 0, tHint = 0, tCap = 0;
  const topicOf = () => topicBase + '/' + myId;

  function startLink(url) {
    const L = { url, ws: null, ok: false, buf: new Uint8Array(0), ping: 0, retry: 0, dead: false, timer: 0 };
    links.push(L);
    openLink(L);
  }
  function retryLink(L) {
    if (L.dead) return;
    L.retry++;
    L.timer = setTimeout(() => openLink(L), Math.min(10000, 1000 * L.retry));
  }
  function openLink(L) {
    if (L.dead) return;
    let ws;
    try { ws = new WebSocket(L.url, 'mqtt'); } catch (e) { retryLink(L); return; }
    ws.binaryType = 'arraybuffer';
    L.ws = ws; L.ok = false; L.buf = new Uint8Array(0);
    ws.onopen = () => {
      if (L.ws !== ws) return;
      const will = JSON.stringify({ i: myId, q: 999999999, t: 'leave' });
      ws.send(mqPacket(0x10, mqStr('MQTT'), [4, 0x06, 0, 30], mqStr('sn-' + myId), mqStr(topicOf()), mqStr(will)));
    };
    ws.onmessage = e => { if (L.ws === ws) feed(L, new Uint8Array(e.data)); };
    const lost = () => {
      if (L.ws !== ws) return;
      L.ws = null; L.ok = false; clearInterval(L.ping);
      linkStatus();
      retryLink(L);
    };
    ws.onclose = lost; ws.onerror = lost;
  }
  function closeLink(L) {
    L.dead = true; clearInterval(L.ping); clearTimeout(L.timer);
    const ws = L.ws;
    L.ws = null; L.ok = false;
    if (ws) { try { if (ws.readyState === 1) ws.send(mqPacket(0xE0)); ws.close(); } catch (e) {} }
  }
  function feed(L, data) {
    const nb = new Uint8Array(L.buf.length + data.length);
    nb.set(L.buf); nb.set(data, L.buf.length);
    L.buf = nb;
    for (;;) {
      const b = L.buf;
      if (b.length < 2) return;
      let mul = 1, len = 0, i = 1, byte;
      do {
        if (i >= b.length) return;
        byte = b[i++]; len += (byte & 127) * mul; mul *= 128;
        if (i > 5) { L.buf = new Uint8Array(0); return; }
      } while (byte & 128);
      if (b.length < i + len) return;
      const type = b[0] >> 4, flags = b[0] & 15, body = b.subarray(i, i + len);
      L.buf = b.subarray(i + len);
      onPacket(L, type, flags, body);
    }
  }
  function onPacket(L, type, flags, body) {
    if (type === 2) { // CONNACK
      if (body[1] !== 0) { const ws = L.ws; if (ws) { try { ws.close(); } catch (e) {} } return; }
      if (L.ws) L.ws.send(mqPacket(0x82, [0, 1], mqStr(topicBase + '/+'), [0]));
    } else if (type === 9) { // SUBACK
      L.ok = true; L.retry = 0;
      clearInterval(L.ping);
      L.ping = setInterval(() => { try { if (L.ws && L.ws.readyState === 1) L.ws.send(mqPacket(0xC0)); } catch (e) {} }, 20000);
      onLinkUp();
    } else if (type === 3) { // PUBLISH
      if (body.length < 2) return;
      const tl = (body[0] << 8) | body[1];
      let off = 2 + tl;
      if ((flags >> 1) & 3) off += 2;
      if (off > body.length) return;
      onEnvelope(TD.decode(body.subarray(off)));
    }
  }

  function linkStatus() {
    if (!joined) return;
    const any = links.some(l => l.ok);
    status(any ? 'Онлайн · комната ' + roomCode : 'Связь потеряна, переподключаюсь…', !any);
  }
  function onLinkUp() {
    if (!role) return;
    if (!joined) {
      clearTimeout(tFail); busy = false;
      lastCosKey = cosKey(myCos());
      onMsg({ t: 'hello', id: myId, room: roomCode, players: [] });
      tHi = setInterval(sendHi, 3000);
      tSweep = setInterval(sweep, 1000);
      tCap = setTimeout(capCheck, 2500);
      tHint = setTimeout(hint, 3500);
    } else linkStatus();
    sendHi();
  }

  const sendHi = () => send({ t: 'hi', name: S.name, cos: myCos() });
  function replyHi() { const n = Date.now(); if (n - lastHiReply > 1000) { lastHiReply = n; sendHi(); } }
  const knownCount = () => { let n = 0; peers.forEach(p => { if (p.known) n++; }); return n; };
  function capCheck() { if (joined && knownCount() >= MAXP) teardown('Комната заполнена (максимум ' + MAXP + ' игроков)', true); }
  function hint() { if (joined && joinMode && !knownCount()) status('Пока никого нет в комнате. Проверь код.', true); }
  function sweep() {
    const now = Date.now();
    peers.forEach((pr, id) => {
      if (now - pr.seen > 9000) { if (pr.known) onMsg({ t: 'leave', id }); peers.delete(id); }
    });
  }

  // разбор сообщений других игроков
  function onEnvelope(txt) {
    let m;
    try { m = JSON.parse(txt); } catch (e) { return; }
    if (!joined || !m || typeof m !== 'object' || typeof m.i !== 'string' || m.i === myId || m.i.length > 16) return;
    const q = +m.q;
    if (!Number.isFinite(q)) return;
    let pr = peers.get(m.i);
    if (!pr) {
      if (m.t === 'leave') return;
      if (peers.size >= 24) return;
      pr = { q: 0, seen: 0, known: false };
      peers.set(m.i, pr);
    }
    if (q <= pr.q) return; // дубликат (пришло через второй брокер)
    pr.q = q; pr.seen = Date.now();
    switch (m.t) {
      case 'hi': {
        const cos = cleanCos(m.cos);
        if (!pr.known) {
          pr.known = true;
          onMsg({ t: 'join', p: { id: m.i, name: cleanName(m.name), cos } });
          replyHi();
        } else {
          const r = remotes.get(m.i);
          if (r && cos && (!r.cos || cosKey(r.cos) !== cosKey(cos))) { r.cos = cos; applyCos(r, cos); refreshUi(); }
        }
        break;
      }
      case 's':
        if (!pr.known) replyHi(); else onMsg(Object.assign(cleanState(m), { t: 's', id: m.i }));
        break;
      case 'cos': {
        const c = cleanCos(m.cos);
        if (pr.known && c) onMsg({ t: 'cos', id: m.i, cos: c });
        break;
      }
      case 'chat': {
        const tx = String(m.m || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 120);
        const r = remotes.get(m.i);
        if (pr.known && tx) onMsg({ t: 'chat', id: m.i, name: r ? r.name : 'Паук', m: tx });
        break;
      }
      case 'emo':
        if (pr.known) onMsg({ t: 'emo', id: m.i, e: num(m.e, 0, 4, 0) | 0 });
        break;
      case 'leave':
        if (pr.known) onMsg({ t: 'leave', id: m.i });
        peers.delete(m.i);
        break;
    }
  }

  // отправка своих данных через все подключённые брокеры
  function sendRaw(o) {
    if (!myId) return;
    const text = JSON.stringify(Object.assign({ i: myId, q: ++seq }, o));
    const topic = topicOf();
    links.forEach(L => {
      if (!L.ok || !L.ws || L.ws.readyState !== 1) return;
      if (o.t === 's' && L.ws.bufferedAmount > 200000) return;
      try { mqPublish(L, topic, text); } catch (e) {}
    });
  }
  const send = o => { if (joined) sendRaw(o); };

  // Полностью выйти из комнаты и очистить игроков
  function teardown(text, err) {
    if (joined) { try { sendRaw({ t: 'leave' }); } catch (e) {} }
    clearTimeout(tFail); clearTimeout(tCap); clearTimeout(tHint);
    clearInterval(tHi); clearInterval(tSweep); clearInterval(tWatch);
    const ls = links; links = [];
    ls.forEach(closeLink);
    peers.clear();
    role = null; joined = false; myId = null; roomCode = ''; busy = false;
    clearRemotes();
    status(text || 'Не подключено', err);
    refreshUi();
  }

  function readName() {
    S.name = cleanName(q('mpName').value || S.name);
    q('mpName').value = S.name;
    saveS();
  }

  function startRoom(code, mode) {
    roomCode = code; joinMode = mode === 'join'; topicBase = 'spidernight/v2/' + code;
    myId = (Math.random().toString(36) + '000000').slice(2, 8);
    seq = 0; fallbackOn = false; lastOk = Date.now(); peers.clear(); links = [];
    role = 'room'; busy = true; joined = false;
    status(joinMode ? 'Подключаюсь…' : 'Создаю комнату…');
    refreshUi();
    BROKERS.forEach(startLink);
    tFail = setTimeout(() => { if (role && !joined) teardown('Не удалось подключиться. Проверь интернет и попробуй ещё раз.', true); }, 20000);
    tWatch = setInterval(() => {
      if (links.some(l => l.ok)) lastOk = Date.now();
      else if (!fallbackOn && Date.now() - lastOk > 8000) { fallbackOn = true; startLink(FALLBACK); }
    }, 2000);
  }

  function createRoom() {
    if (busy || role) return;
    readName();
    let code = '';
    for (let i = 0; i < 5; i++) code += ALPHA[Math.floor(Math.random() * ALPHA.length)];
    startRoom(code, 'create');
  }
  function joinRoom() {
    if (busy || role) return;
    const code = q('mpCodeIn').value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (code.length < 4) { status('Введи код комнаты', true); return; }
    readName();
    S.code = code; saveS();
    startRoom(code, 'join');
  }
  function leaveRoom() { teardown('Ты вышел из комнаты'); }

  function onMsg(m) {
    switch (m.t) {
      case 'hello':
        joined = true; myId = m.id; roomCode = m.room;
        status('Онлайн · комната ' + m.room);
        (m.players || []).forEach(p => addRemote(p, true));
        refreshUi();
        toast('Комната ' + m.room + (remotes.size ? ' · игроков: ' + (remotes.size + 1) : ''));
        break;
      case 'join':
        addRemote(m.p); refreshUi(); toast(m.p.name + ' в игре');
        if (joined) linkStatus();
        break;
      case 'leave': {
        const r = remotes.get(m.id);
        if (r) { removeRemote(r); remotes.delete(m.id); refreshUi(); toast(r.name + ' вышел'); }
        break;
      }
      case 's': {
        const r = remotes.get(m.id);
        if (r) { r.s = m; r.t = performance.now(); }
        break;
      }
      case 'cos': {
        const r = remotes.get(m.id);
        if (r && m.cos) { r.cos = m.cos; applyCos(r, m.cos); refreshUi(); }
        break;
      }
      case 'chat': {
        logLine(m.name, m.m);
        const r = remotes.get(m.id);
        if (r) bubble(r, m.m);
        break;
      }
      case 'emo': {
        const r = remotes.get(m.id);
        if (r) emote(r, EMO[m.e | 0] || EMO[0]);
        break;
      }
    }
  }

  /* ---------- аватары ---------- */
  let paths = null;
  function getPaths() {
    if (paths) return paths;
    const f = o => pathOf(hero, o);
    paths = {
      legL: f(legL), legR: f(legR), armL: f(armL), armR: f(armR), body: f(body), headG: f(headG), hand: f(handAnchor),
      civ: f(civ.g), c1: f(civ.l1), c2: f(civ.l2), a1: f(civ.a1), a2: f(civ.a2)
    };
    return paths;
  }

  function textTex(text, w, h, font, bg) {
    const k = document.createElement('canvas');
    k.width = w; k.height = h;
    const g = k.getContext('2d');
    if (bg) {
      g.fillStyle = bg;
      g.beginPath();
      if (g.roundRect) g.roundRect(2, 2, w - 4, h - 4, h / 2.4); else g.rect(2, 2, w - 4, h - 4);
      g.fill();
    }
    g.fillStyle = '#f4ead8'; g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(text, w / 2, h / 2 + 2, w - 20);
    return new THREE.CanvasTexture(k);
  }
  function mkSprite(tex, sx, sy) {
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, fog: false }));
    sp.scale.set(sx, sy, 1); sp.renderOrder = 20; sp.visible = false;
    scene.add(sp);
    return sp;
  }
  function killSprite(sp) {
    if (!sp) return;
    scene.remove(sp);
    if (sp.material.map) sp.material.map.dispose();
    sp.material.dispose();
  }

  function addRemote(p, quiet) {
    if (!p || p.id === myId || remotes.has(p.id)) return;
    const pa = getPaths();
    const g = hero.clone(true);
    const cv = document.createElement('canvas'); cv.width = cv.height = 128;
    const tex = new THREE.CanvasTexture(cv); tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    const mSuit = new THREE.MeshLambertMaterial({ map: tex });
    const mAcc = new THREE.MeshLambertMaterial({ color: 0xffb347, emissive: 0x553300 });
    g.traverse(m => { if (m.isMesh) { if (m.material === suit) m.material = mSuit; else if (m.material === acc) m.material = mAcc; } });
    const o = () => new THREE.Object3D();
    const car = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1, 4.2), new THREE.MeshLambertMaterial({ color: 0xffb347 }));
    car.visible = false; scene.add(car);
    const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0xffffff }));
    line.frustumCulled = false; line.visible = false; scene.add(line);
    g.visible = false; scene.add(g);
    const r = {
      id: p.id, name: p.name || 'Паук', cos: p.cos || null, g, cv, tex, mSuit, mAcc, car, line,
      P: {
        legL: byPath(g, pa.legL) || o(), legR: byPath(g, pa.legR) || o(), armL: byPath(g, pa.armL) || o(), armR: byPath(g, pa.armR) || o(),
        body: byPath(g, pa.body) || o(), hand: byPath(g, pa.hand) || g,
        civ: byPath(g, pa.civ) || o(), c1: byPath(g, pa.c1) || o(), c2: byPath(g, pa.c2) || o(), a1: byPath(g, pa.a1) || o(), a2: byPath(g, pa.a2) || o()
      },
      tag: mkSprite(textTex(p.name || 'Паук', 256, 64, 'bold 30px system-ui,sans-serif', 'rgba(13,11,26,.62)'), 2.8, .7),
      bub: null, bubT: 0, emo: null, emoT: 0,
      s: p.s || null, t: performance.now(), pos: new THREE.Vector3(), init: false, ph: 0, vis: false
    };
    if (r.cos) applyCos(r, r.cos); else applyCos(r, { b: '#17122e', l: '#ffb347', a: 0xffb347, e: 0x553300 });
    remotes.set(p.id, r);
  }

  function applyCos(r, c) {
    paintCv(r.cv, c.b, c.l); r.tex.needsUpdate = true;
    r.mAcc.color.setHex(c.a); r.mAcc.emissive.setHex(c.e);
    r.car.material.color.setHex(c.a);
  }

  function removeRemote(r) {
    scene.remove(r.g); scene.remove(r.car); scene.remove(r.line);
    r.tex.dispose(); r.mSuit.dispose(); r.mAcc.dispose();
    r.car.geometry.dispose(); r.car.material.dispose();
    r.line.geometry.dispose(); r.line.material.dispose();
    killSprite(r.tag); killSprite(r.bub); killSprite(r.emo);
  }
  function clearRemotes() { remotes.forEach(removeRemote); remotes.clear(); }

  function bubble(r, text) {
    killSprite(r.bub);
    const t = text.length > 44 ? text.slice(0, 43) + '…' : text;
    r.bub = mkSprite(textTex(t, 512, 80, '28px system-ui,sans-serif', 'rgba(244,234,216,.18)'), 5.4, .85);
    r.bubT = 6;
  }
  function emote(r, e) {
    killSprite(r.emo);
    r.emo = mkSprite(emojiTex(e), 1.5, 1.5);
    r.emoT = 3;
  }

  const _v = new THREE.Vector3();
  function updRemote(r, dt, now) {
    const s = r.s;
    const hide = !s || s.hid || inHome || !started;
    if (hide) {
      r.g.visible = r.car.visible = r.line.visible = r.tag.visible = false;
      if (r.bub) r.bub.visible = false;
      if (r.emo) r.emo.visible = false;
      r.vis = false;
      return;
    }
    const age = Math.min(.25, (now - r.t) / 1000);
    const tx = s.x + s.vx * age, tz = s.z + s.vz * age, ty = s.g ? s.y : s.y + s.vy * age;
    if (!r.init || Math.abs(tx - r.pos.x) + Math.abs(tz - r.pos.z) > 40) { r.pos.set(tx, ty, tz); r.init = true; }
    else {
      const k = 1 - Math.exp(-14 * dt);
      r.pos.x += (tx - r.pos.x) * k; r.pos.y += (ty - r.pos.y) * k; r.pos.z += (tz - r.pos.z) * k;
    }
    r.vis = true;
    const g = r.g, P_ = r.P;

    if (s.dr) {
      // игрок за рулём: показываем простую «машину»
      g.visible = false; r.line.visible = false;
      r.car.visible = true;
      r.car.position.set(r.pos.x, r.pos.y + .6, r.pos.z);
      r.car.rotation.y = s.ry;
    } else {
      r.car.visible = false;
      g.visible = true;
      g.position.set(r.pos.x, r.pos.y + .05, r.pos.z);
      g.rotation.y = turnTo(g.rotation.y, s.ry, Math.min(1, 14 * dt));
      const civ_ = !!s.civ;
      P_.civ.visible = civ_; P_.body.visible = !civ_; P_.legL.visible = !civ_; P_.legR.visible = !civ_;
      const hs = Math.hypot(s.vx, s.vz);
      let aL = 0, aR = 0, lL = 0, lR = 0;
      if (s.cl) {
        const cs = Math.sin(now / 110);
        aL = -2.6 + cs * .5; aR = -2.6 - cs * .5; lL = cs * .7; lR = -cs * .7;
      } else if (s.w) {
        const wx = s.w[0] - r.pos.x, wz = s.w[2] - r.pos.z;
        const f = wx * Math.sin(g.rotation.y) + wz * Math.cos(g.rotation.y), dy = s.w[1] - (r.pos.y + 1.45);
        aR = -Math.atan2(f, -dy); aL = -1.4; lL = .5; lR = -.3;
      } else if (s.sw) {
        const c = Math.sin(now / 220);
        aL = -2.2 + c * .6; aR = -2.2 - c * .6; lL = c * .4; lR = -c * .4;
      } else if (!s.g) {
        aL = aR = -1.2; lL = .45; lR = -.45;
      } else {
        r.ph += dt * hs * .9;
        const k = Math.sin(r.ph) * Math.min(1, hs / 8);
        aL = k * .9; aR = -k * .9; lL = -k * .9; lR = k * .9;
      }
      if (s.pu) aR = -1.7;
      if (civ_) {
        P_.a1.rotation.x = aL; P_.a2.rotation.x = aR; P_.c1.rotation.x = lL; P_.c2.rotation.x = lR;
      } else {
        P_.armL.rotation.x = aL; P_.armR.rotation.x = aR; P_.legL.rotation.x = lL; P_.legR.rotation.x = lR;
      }
      // паутина
      if (s.w && !civ_) {
        P_.hand.getWorldPosition(_v);
        const a = r.line.geometry.attributes.position;
        a.setXYZ(0, _v.x, _v.y, _v.z); a.setXYZ(1, s.w[0], s.w[1], s.w[2]); a.needsUpdate = true;
        r.line.visible = true;
      } else r.line.visible = false;
    }

    // имя, реплика, эмодзи
    const dx = r.pos.x - cam.position.x, dy = r.pos.y - cam.position.y, dz = r.pos.z - cam.position.z;
    const near = dx * dx + dy * dy + dz * dz < 220 * 220;
    r.tag.visible = near;
    r.tag.position.set(r.pos.x, r.pos.y + (s.dr ? 2.2 : 2.6), r.pos.z);
    if (r.bub) {
      r.bubT -= dt;
      if (r.bubT <= 0) { killSprite(r.bub); r.bub = null; }
      else { r.bub.visible = near; r.bub.position.set(r.pos.x, r.pos.y + 3.4, r.pos.z); }
    }
    if (r.emo) {
      r.emoT -= dt;
      if (r.emoT <= 0) { killSprite(r.emo); r.emo = null; }
      else { r.emo.visible = near; r.emo.position.set(r.pos.x, r.pos.y + 3.1 + (3 - r.emoT) * .35, r.pos.z); }
    }
  }

  /* ---------- отправка своего состояния ---------- */
  const r2 = v => Math.round(v * 100) / 100, r1 = v => Math.round(v * 10) / 10;
  function sendState() {
    const d = drive;
    const pp = d ? d.c.g.position : P.p;
    const o = {
      t: 's', x: r2(pp.x), y: r2(pp.y), z: r2(pp.z),
      ry: r2(d ? d.c.hd : hero.rotation.y),
      vx: r1(d ? Math.sin(d.c.hd) * d.c.speed : P.v.x), vy: r1(d ? 0 : P.v.y), vz: r1(d ? Math.cos(d.c.hd) * d.c.speed : P.v.z),
      g: P.g ? 1 : 0, cl: P.climbing ? 1 : 0, sw: P.swim ? 1 : 0, pu: punchAnim > 0 ? 1 : 0,
      civ: civilian ? 1 : 0, dr: d ? 1 : 0, hid: inHome ? 1 : 0,
      w: (P.web && !d) ? [r1(P.web.x), r1(P.web.y), r1(P.web.z)] : null
    };
    sendRaw(o);
  }

  function frame(dt) {
    const now = performance.now();
    if (joined) {
      if (started) {
        sendT -= dt;
        if (sendT <= 0) { sendT = 1 / 10; sendState(); }
      }
      cosT -= dt;
      if (cosT <= 0) {
        cosT = 1;
        const c = myCos(), k = cosKey(c);
        if (k !== lastCosKey) { lastCosKey = k; send({ t: 'cos', cos: c }); }
      }
    }
    if (!remotes.size) return;
    remotes.forEach(r => updRemote(r, dt, now));
    // точки на миникарте (рисуем в те же кадры, что и сама карта)
    if (started && (mapT - 1) % 3 === 0) {
      remotes.forEach(r => {
        if (!r.vis) return;
        mx.fillStyle = (r.cos && r.cos.l) || '#fff';
        mx.beginPath();
        mx.arc((r.pos.x + 400) * MSC, (r.pos.z + 400) * MSC, 3, 0, 6.3);
        mx.fill();
        mx.strokeStyle = '#fff'; mx.lineWidth = 1; mx.stroke();
      });
    }
  }

  /* ---------- чат и эмодзи ---------- */
  function logLine(name, text) {
    const log = q('mpLog');
    const d = document.createElement('div');
    const b = document.createElement('b');
    b.textContent = name + ': ';
    d.appendChild(b);
    d.appendChild(document.createTextNode(text));
    log.appendChild(d);
    while (log.children.length > 5) log.removeChild(log.firstChild);
    setTimeout(() => { if (d.parentNode) d.parentNode.removeChild(d); }, 12000);
  }

  let chatOpen = false;
  function openChat() {
    if (!joined) return;
    chatOpen = true;
    q('mpEmoRow').style.display = 'none';
    q('mpChatBar').style.display = 'flex';
    q('mpMsg').focus();
  }
  function closeChat() {
    chatOpen = false;
    q('mpChatBar').style.display = 'none';
    q('mpMsg').blur();
  }
  function sendChat() {
    const inp = q('mpMsg');
    const t = inp.value.trim();
    inp.value = '';
    if (t && joined) {
      send({ t: 'chat', m: t });
      logLine(S.name, t);
    }
    closeChat();
  }
  q('mpChatBtn').addEventListener('pointerdown', e => { e.preventDefault(); chatOpen ? closeChat() : openChat(); });
  q('mpEmoBtn').addEventListener('pointerdown', e => {
    e.preventDefault();
    closeChat();
    const row = q('mpEmoRow');
    row.style.display = row.style.display === 'flex' ? 'none' : 'flex';
  });
  q('mpEmoRow').addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    const i = +b.dataset.e;
    send({ t: 'emo', e: i });
    q('mpEmoRow').style.display = 'none';
    // свой эмодзи над собой видят остальные; себе покажем через тост
    toast(EMO[i]);
  });
  q('mpSend').addEventListener('click', sendChat);
  q('mpMsg').addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); sendChat(); }
    else if (e.key === 'Escape') { e.preventDefault(); closeChat(); }
  });
  addEventListener('keydown', e => {
    if (e.code === 'Enter' && joined && started && !chatOpen && !paused && !(document.activeElement && document.activeElement.tagName === 'INPUT')) {
      e.preventDefault(); openChat();
    }
  });

  /* ---------- панель подключения ---------- */
  function openPanel() {
    q('mpName').value = S.name;
    if (!q('mpCodeIn').value) q('mpCodeIn').value = S.code || '';
    if (!statusText) status('Не подключено');
    refreshUi();
    q('mpPanel').style.display = 'flex';
  }
  function closePanel() { q('mpPanel').style.display = 'none'; }
  mpOpen.addEventListener('click', openPanel);
  mpOpen2.addEventListener('click', openPanel);
  q('mpClose').addEventListener('click', closePanel);
  q('mpCreate').addEventListener('click', createRoom);
  q('mpJoin').addEventListener('click', joinRoom);
  q('mpLeave').addEventListener('click', leaveRoom);
  q('mpShare').addEventListener('click', () => {
    const text = 'Заходи в Spider Night! Код комнаты: ' + roomCode;
    if (navigator.share) navigator.share({ text }).catch(() => {});
    else if (navigator.clipboard) navigator.clipboard.writeText(roomCode).then(() => toast('Код скопирован')).catch(() => {});
  });

  window.MP = { frame, get joined() { return joined; }, remotes };

  refreshUi();
})();
